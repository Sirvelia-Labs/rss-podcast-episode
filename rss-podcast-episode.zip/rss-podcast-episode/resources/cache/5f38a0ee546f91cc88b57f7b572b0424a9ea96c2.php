Hola
<?php /**PATH /app/wp-content/plugins/rss-podcast-episode/resources/views/blocks/single-podcast.blade.php ENDPATH**/ ?>